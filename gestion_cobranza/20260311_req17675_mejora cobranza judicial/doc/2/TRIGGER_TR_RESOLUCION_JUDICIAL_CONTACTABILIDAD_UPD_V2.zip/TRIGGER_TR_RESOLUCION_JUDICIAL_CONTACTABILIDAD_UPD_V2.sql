CREATE TRIGGER TR_RESOLUCION_JUDICIAL_CONTACTABILIDAD_UPD
    ON [dbo].[RESOLUCION_JUDICIAL]
    AFTER UPDATE
AS
BEGIN
    SET NOCOUNT ON;

    -- Si no hay filas actualizadas, no hacemos nada
    IF NOT EXISTS (SELECT 1 FROM inserted)
        RETURN;

    -- Actualizar "otras" resoluciones del mismo deudor con REJ_FECREG >= fecha de la fila actualizada
    -- y que no est�n impresas
    UPDATE r
    SET
        r.REJ_DIRECCION = i.REJ_DIRECCION,
        r.CMN_CODIGO    = i.CMN_CODIGO,
        r.REJ_FONO1     = i.REJ_FONO1,
        r.REJ_FONO2     = i.REJ_FONO2,
        r.REJ_FONO3     = i.REJ_FONO3,
        r.REJ_EMAIL     = i.REJ_EMAIL,
        r.REJ_CTO_RUT   = i.REJ_CTO_RUT,
        r.REJ_CTO_NOM   = i.REJ_CTO_NOM,
        r.REJ_CTO_FONO  = i.REJ_CTO_FONO,
        r.REJ_CTO_TIPO  = i.REJ_CTO_TIPO,
        r.RAC_CODIGO    = i.RAC_CODIGO
    FROM [dbo].[RESOLUCION_JUDICIAL] r
    INNER JOIN inserted i
        ON r.DDR_RUT = i.DDR_RUT
    WHERE
        r.REJ_FECREG >= i.REJ_FECREG
        AND r.REJ_FECIMPRIME IS NULL
        AND r.REJ_FOLIO <> i.REJ_FOLIO;
END;
